<?php

namespace Cassio\EvalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CassioEvalBundle extends Bundle
{
}
