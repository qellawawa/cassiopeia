#include<stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
  int n1, n2, estado, i, j, pos;

  char *c1 = "OIE";
  char *c2 = "IEO";
  char *c3 = "EOI";

  estado = 0;
  pos = 0;

  if(argc != 3){
    printf("faltan o hay muchos argumentos: %d\n", argc);
    exit(1);
  }

  n1 = atoi(argv[1]);
  n2 = atoi(argv[2]);

  if(n1 < 3 | n1 > 100 | n2 < 3 | n2 > 100)
  {
    exit(1);
  }

  for(i = 0; i < n1; i++)
  {
    for(j = 0; j < n2; j++)
    {
      switch(estado)
      {
        case 0: 
          printf("%c", c1[pos]);
          break;
        case 1: 
          printf("%c", c2[pos]);
          break;
        case 2: 
          printf("%c", c3[pos]);
          break;
      }
      if(pos < 2) 
        pos++;
      else
        pos = 0;
    }
    pos = 0;
    if(estado < 2) 
      estado++;
    else
      estado = 0;
    printf("\n");
  }
}
